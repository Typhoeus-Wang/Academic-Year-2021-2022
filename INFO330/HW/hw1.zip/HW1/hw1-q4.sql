-- hw1-q4
SELECT * 
FROM MyRestaurants;