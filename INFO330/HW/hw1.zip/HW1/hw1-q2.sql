-- hw1-q2
CREATE TABLE MyRestaurants (
    name     VARCHAR(256),
    cuisine  VARCHAR(256),
    distance INT,
    lastvist DATE,
    liked    BIT
);
