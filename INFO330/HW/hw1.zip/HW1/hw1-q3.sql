-- hw1-q3
INSERT INTO MyRestaurants 
VALUES ('little duck', 'guobaorou', '10', '2002-02-25', 1);

INSERT INTO MyRestaurants 
VALUES ('CQ Hotpot', 'beef soup', '134', '2002-02-01', 0);

INSERT INTO MyRestaurants 
VALUES ('Dairy King', 'ice cream', '25', '2021-03-14', 1);

INSERT INTO MyRestaurants 
VALUES ('Gong Tea', 'bubble tea', '87', '2021-06-24', 0);

INSERT INTO MyRestaurants 
VALUES ('ZhongYu', 'teriyaki', '64', '2021-06-28', NULL);